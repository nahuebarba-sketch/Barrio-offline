# Barrio Offline — prototipo 0.1

Aplicación Android experimental para intercambiar mensajes de texto entre dos teléfonos cercanos por Bluetooth clásico, sin Internet.

## Prueba inicial
1. Instalá el APK en dos teléfonos Android con Bluetooth.
2. En ambos, abrí Ajustes > Bluetooth y emparejá los teléfonos.
3. En el teléfono que recibirá, abrí la app y tocá **Esperar mensaje entrante**.
4. En el otro, tocá **Actualizar teléfonos emparejados**, elegí el teléfono y tocá **Conectar al teléfono elegido**.
5. Escribí y enviá un mensaje.

El teléfono que espera debe mantener la app abierta. Este prototipo no retransmite mensajes entre teléfonos, no cifra mensajes y no debe usarse para emergencias reales. Bluetooth tiene alcance limitado.
