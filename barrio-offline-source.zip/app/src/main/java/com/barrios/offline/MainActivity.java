package com.barrios.offline;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int REQ_PERMS = 41;
    private static final int REQ_ENABLE = 42;
    private static final UUID APP_UUID = UUID.fromString("7c2a8f10-9f4b-4e55-8d20-6b4b61726f77");
    private BluetoothAdapter adapter;
    private TextView status, log;
    private EditText message;
    private Spinner devices;
    private ArrayList<BluetoothDevice> paired = new ArrayList<>();
    private BluetoothSocket socket;
    private BluetoothServerSocket serverSocket;
    private final android.os.Handler handler = new android.os.Handler();
    private volatile boolean running = true;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        adapter = BluetoothAdapter.getDefaultAdapter();
        buildUi();
        if (adapter == null) { status.setText("Este teléfono no tiene Bluetooth."); return; }
        requestPermissionsIfNeeded();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 24, 28, 20);
        root.setBackgroundColor(0xFFF3F6F4);
        ScrollView sc = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this);
        title.setText("Barrio Offline");
        title.setTextSize(29); title.setTextColor(0xFF123D32); title.setGravity(Gravity.CENTER);
        title.setPadding(0, 8, 0, 6);
        content.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Mensajes locales por Bluetooth · sin Internet");
        subtitle.setTextSize(14); subtitle.setGravity(Gravity.CENTER);
        subtitle.setTextColor(0xFF4D625A); subtitle.setPadding(0,0,0,18);
        content.addView(subtitle);
        status = new TextView(this);
        status.setText("Preparando Bluetooth…"); status.setTextSize(15); status.setTextColor(0xFF123D32);
        status.setPadding(12,12,12,12); status.setBackgroundColor(0xFFE0EBE5);
        content.addView(status);
        Button enable = new Button(this); enable.setText("Activar Bluetooth");
        enable.setOnClickListener(v -> enableBluetooth()); content.addView(enable);
        Button visible = new Button(this); visible.setText("Permitir que me encuentren");
        visible.setOnClickListener(v -> makeDiscoverable()); content.addView(visible);
        Button listen = new Button(this); listen.setText("Esperar mensaje entrante");
        listen.setOnClickListener(v -> startServer()); content.addView(listen);
        TextView label = new TextView(this); label.setText("Teléfonos ya emparejados"); label.setTextSize(16);
        label.setTextColor(0xFF123D32); label.setPadding(0,12,0,4); content.addView(label);
        devices = new Spinner(this); content.addView(devices);
        Button refresh = new Button(this); refresh.setText("Actualizar teléfonos emparejados");
        refresh.setOnClickListener(v -> loadPaired()); content.addView(refresh);
        Button connect = new Button(this); connect.setText("Conectar al teléfono elegido");
        connect.setOnClickListener(v -> connectSelected()); content.addView(connect);
        log = new TextView(this); log.setText("Los mensajes aparecerán aquí.\n"); log.setTextSize(14);
        log.setTextColor(0xFF202A25); log.setPadding(12,12,12,12); log.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 250); lp.setMargins(0,12,0,8);
        content.addView(log, lp);
        message = new EditText(this); message.setHint("Escribí un mensaje…"); content.addView(message);
        Button send = new Button(this); send.setText("Enviar mensaje");
        send.setOnClickListener(v -> sendMessage()); content.addView(send);
        sc.addView(content); root.addView(sc, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    private boolean has(String p) { return Build.VERSION.SDK_INT < 23 || checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }
    private void requestPermissionsIfNeeded() {
        ArrayList<String> p = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) {
            for (String x : new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_ADVERTISE})
                if (!has(x)) p.add(x);
        } else if (Build.VERSION.SDK_INT >= 23 && !has(Manifest.permission.ACCESS_FINE_LOCATION)) p.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (!p.isEmpty()) requestPermissions(p.toArray(new String[0]), REQ_PERMS);
        else { updateStatus(); loadPaired(); }
    }

    @Override public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req == REQ_PERMS) { updateStatus(); loadPaired(); }
    }

    private void updateStatus() {
        try { status.setText(adapter != null && adapter.isEnabled() ? "Bluetooth listo. Emparejá los teléfonos desde Ajustes." : "Bluetooth está apagado."); }
        catch (SecurityException e) { status.setText("Aceptá los permisos de Bluetooth para continuar."); }
    }
    private void enableBluetooth() {
        if (adapter == null) return;
        try {
            if (!adapter.isEnabled()) startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_ENABLE);
            else { updateStatus(); loadPaired(); }
        } catch (SecurityException e) { requestPermissionsIfNeeded(); }
    }
    private void makeDiscoverable() {
        try {
            Intent i = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            i.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
            startActivity(i);
        } catch (SecurityException e) { status.setText("Falta permiso de Bluetooth."); }
    }
    private void loadPaired() {
        if (adapter == null) return;
        try {
            paired.clear();
            Set<BluetoothDevice> set = adapter.getBondedDevices();
            ArrayList<String> names = new ArrayList<>();
            for (BluetoothDevice d : set) { paired.add(d); String n; try { n=d.getName(); } catch(Exception e){n=null;} names.add((n==null?"Teléfono":n)+" · "+d.getAddress()); }
            if (names.isEmpty()) names.add("Ningún teléfono emparejado todavía");
            devices.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
            updateStatus();
        } catch (SecurityException e) { status.setText("Aceptá los permisos de Bluetooth."); }
    }
    private void startServer() {
        if (adapter == null) return;
        new Thread(() -> {
            try {
                if (Build.VERSION.SDK_INT >= 31 && !has(Manifest.permission.BLUETOOTH_CONNECT)) {
                    handler.post(() -> status.setText("Concedé permisos de Bluetooth."));
                    return;
                }
                serverSocket = adapter.listenUsingRfcommWithServiceRecord("Barrio Offline", APP_UUID);
                handler.post(() -> status.setText("Esperando conexión… mantené esta pantalla abierta."));
                socket = serverSocket.accept();
                handler.post(() -> { status.setText("Conectado. Ya podés intercambiar mensajes."); append("Conexión recibida.\n"); });
                serverSocket.close();
                readLoop(socket);
            } catch (Exception e) { handler.post(() -> status.setText("No se pudo esperar conexión: " + e.getMessage())); }
        }).start();
    }
    private void connectSelected() {
        if (paired.isEmpty() || devices.getSelectedItemPosition() >= paired.size()) {
            status.setText("Primero emparejá ambos teléfonos en Ajustes > Bluetooth."); return;
        }
        BluetoothDevice d = paired.get(devices.getSelectedItemPosition());
        status.setText("Conectando…");
        new Thread(() -> {
            try {
                BluetoothSocket s = d.createRfcommSocketToServiceRecord(APP_UUID);
                s.connect(); socket = s;
                handler.post(() -> { status.setText("Conectado. Ya podés intercambiar mensajes."); append("Conexión establecida.\n"); });
                readLoop(s);
            } catch (Exception e) { handler.post(() -> status.setText("No conectó. En el otro teléfono tocá «Esperar mensaje entrante». " + e.getMessage())); }
        }).start();
    }
    private void readLoop(BluetoothSocket s) {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
            String line;
            while (running && (line=in.readLine())!=null) { final String msg=line; handler.post(() -> append("Vecino: "+msg+"\n")); }
        } catch (Exception e) { handler.post(() -> append("Conexión finalizada.\n")); }
    }
    private void sendMessage() {
        String m = message.getText().toString().trim();
        if (m.isEmpty()) return;
        BluetoothSocket s = socket;
        if (s == null || !s.isConnected()) { status.setText("Todavía no hay conexión. Emparejá y conectá los teléfonos."); return; }
        new Thread(() -> {
            try {
                PrintWriter out = new PrintWriter(new OutputStreamWriter(s.getOutputStream(), "UTF-8"), true);
                out.println(m);
                handler.post(() -> { append("Yo: "+m+"\n"); message.setText(""); });
            } catch (Exception e) { handler.post(() -> status.setText("No se pudo enviar el mensaje.")); }
        }).start();
    }
    private void append(String s) { log.append(s); }
    @Override protected void onDestroy() {
        running=false;
        try { if(socket!=null) socket.close(); } catch(Exception ignored) {}
        try { if(serverSocket!=null) serverSocket.close(); } catch(Exception ignored) {}
        super.onDestroy();
    }
}
